"""
Centralized relay control - THE ONLY place that touches GPIO.
Provides idempotent, rate-limited relay control with anti-flap protection.
"""
import time
from collections import deque, defaultdict
from typing import Dict, Optional, Any
import logging

try:
    from gpiozero import OutputDevice
    GPIO_AVAILABLE = True
except ImportError:
    GPIO_AVAILABLE = False
    # Mock for development
    class OutputDevice:
        def __init__(self, pin, active_high=True):
            self.pin = pin
            self.active_high = active_high
            self._value = False
        
        @property
        def value(self):
            return self._value
        
        @value.setter
        def value(self, val):
            self._value = val

logger = logging.getLogger(__name__)

# Relay registry: name -> BCM pin
RELAY_PINS = {
    "lights": 21,
    "chiller_pump": 16,
    "chiller_power": 20,
    "main_pump": 26,
    "dosing_grow": 6,
    "dosing_micro": 13,
    "dosing_bloom": 19,
    "dosing_ph_up": 5,
}

# Minimum ON/OFF times to prevent short-cycling (seconds)
MIN_ON = {
    "chiller_power": 300,  # 5 minutes
    "chiller_pump": 120,   # 2 minutes
    "main_pump": 60,       # 1 minute
    "lights": 30,          # 30 seconds
    "dosing_*": 0,         # No restriction
    "ph_*": 0,             # No restriction
}

MIN_OFF = {
    "chiller_power": 300,  # 5 minutes
    "chiller_pump": 120,   # 2 minutes
    "main_pump": 30,       # 30 seconds
    "lights": 10,          # 10 seconds
    "dosing_*": 0,         # No restriction
    "ph_*": 0,             # No restriction
}

# Reason constants
REASON_APPLY_SETTINGS = "apply_settings"
REASON_SCHEDULE_ON = "schedule_on"
REASON_SCHEDULE_OFF = "schedule_off"
REASON_CATCHUP = "catchup"
REASON_OVERRIDE = "override"
REASON_EMERGENCY = "emergency"
REASON_HEALTH_GUARD = "health_guard"

# Global state
_devices: Dict[str, OutputDevice] = {}
_last_state: Dict[str, bool] = {}
_last_change_ts: Dict[str, float] = {}
_last_reason: Dict[str, str] = {}
_change_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=20))
_antiflap_until: Dict[str, float] = {}

def _get_min_time(relay_name: str, times_dict: Dict[str, int]) -> int:
    """Get minimum time for relay, supporting wildcard matching."""
    # Exact match first
    if relay_name in times_dict:
        return times_dict[relay_name]
    
    # Wildcard matching
    for pattern, time_val in times_dict.items():
        if pattern.endswith("*"):
            prefix = pattern[:-1]
            if relay_name.startswith(prefix):
                return time_val
    
    return 0  # Default

def _elapsed(relay_name: str) -> float:
    """Get elapsed time since last change for relay."""
    if relay_name not in _last_change_ts:
        return 0
    return time.monotonic() - _last_change_ts[relay_name]

def _initialize_device(relay_name: str) -> OutputDevice:
    """Initialize GPIO device for relay."""
    if relay_name not in RELAY_PINS:
        raise ValueError(f"Unknown relay: {relay_name}")
    
    pin = RELAY_PINS[relay_name]
    # Active-low boards: TRUE = drive LOW
    device = OutputDevice(pin, active_high=False)
    return device

def _update_antiflap_detector(relay_name: str, new_state: bool):
    """Update anti-flap detection for relay."""
    now = time.monotonic()
    history = _change_history[relay_name]
    history.append((now, new_state))
    
    # Check for excessive changes in last 10 minutes
    cutoff = now - 600  # 10 minutes
    recent_changes = [ts for ts, _ in history if ts > cutoff]
    
    if len(recent_changes) > 6:
        logger.warning(f"anti-flap: excessive changes on {relay_name} ({len(recent_changes)} in 10m), suppressing non-forced toggles for 5 minutes")
        _antiflap_until[relay_name] = now + 300  # 5 minutes

def set_relay(name: str, desired_on: bool, reason: str, force: bool = False) -> Dict[str, Any]:
    """
    Core relay control function - idempotent and rate-limited.
    
    Args:
        name: Relay name from RELAY_PINS
        desired_on: Desired state (True=ON, False=OFF)
        reason: Human-readable reason for change
        force: Skip cooldown and anti-flap protection
    
    Returns:
        Dict with changed, state, reason, cooldown_remaining
    """
    if name not in RELAY_PINS:
        return {"changed": False, "reason": f"unknown_relay: {name}"}
    
    now = time.monotonic()
    
    # Initialize device if needed
    if name not in _devices:
        _devices[name] = _initialize_device(name)
    
    device = _devices[name]
    current_state = _last_state.get(name, False)
    
    # Idempotent check
    if current_state == desired_on:
        return {
            "changed": False,
            "state": current_state,
            "reason": "idempotent",
            "cooldown_remaining": 0
        }
    
    if not force:
        # Anti-flap protection
        if name in _antiflap_until and now < _antiflap_until[name]:
            remaining = int(_antiflap_until[name] - now)
            return {
                "changed": False,
                "state": current_state,
                "reason": "antiflap",
                "cooldown_remaining": remaining
            }
        
        # Cooldown protection
        elapsed = _elapsed(name)
        if current_state:  # Currently ON, check MIN_ON
            min_on = _get_min_time(name, MIN_ON)
            if elapsed < min_on:
                remaining = int(min_on - elapsed)
                return {
                    "changed": False,
                    "state": current_state,
                    "reason": "cooldown",
                    "cooldown_remaining": remaining
                }
        else:  # Currently OFF, check MIN_OFF
            min_off = _get_min_time(name, MIN_OFF)
            if elapsed < min_off:
                remaining = int(min_off - elapsed)
                return {
                    "changed": False,
                    "state": current_state,
                    "reason": "cooldown",
                    "cooldown_remaining": remaining
                }
    
    # Execute the change
    try:
        device.value = desired_on
        _last_state[name] = desired_on
        _last_change_ts[name] = now
        _last_reason[name] = reason
        
        # Update anti-flap detector
        _update_antiflap_detector(name, desired_on)
        
        logger.info(f"relay {name} -> {'ON' if desired_on else 'OFF'} (reason={reason})")
        
        return {
            "changed": True,
            "state": desired_on,
            "reason": reason,
            "cooldown_remaining": 0
        }
    
    except Exception as e:
        logger.error(f"Failed to set relay {name}: {e}")
        return {
            "changed": False,
            "state": current_state,
            "reason": f"error: {e}",
            "cooldown_remaining": 0
        }

def initialize_all_safe_off():
    """Initialize all relays to safe OFF state at boot."""
    logger.info("Initializing all relays to safe OFF state")
    for relay_name in RELAY_PINS:
        set_relay(relay_name, False, "boot_safe_off", force=True)

def get_relay_status() -> Dict[str, Dict[str, Any]]:
    """Get status of all relays for diagnostics."""
    now = time.monotonic()
    status = {}
    
    for name in RELAY_PINS:
        state = _last_state.get(name, False)
        last_change = _last_change_ts.get(name, 0)
        seconds_since_change = int(now - last_change) if last_change else 0
        
        status[name] = {
            "state": state,
            "last_reason": _last_reason.get(name, "unknown"),
            "seconds_since_change": seconds_since_change,
            "antiflap_active": name in _antiflap_until and now < _antiflap_until[name]
        }
    
    return status

def get_antiflap_relays() -> list:
    """Get list of relays currently under anti-flap protection."""
    now = time.monotonic()
    return [name for name, until_time in _antiflap_until.items() if now < until_time]

# Convenience functions for specific relays
def set_lights(on: bool, reason: str, force: bool = False) -> Dict[str, Any]:
    return set_relay("lights", on, reason, force)

def set_chiller_power(on: bool, reason: str, force: bool = False) -> Dict[str, Any]:
    return set_relay("chiller_power", on, reason, force)

def set_chiller_pump(on: bool, reason: str, force: bool = False) -> Dict[str, Any]:
    return set_relay("chiller_pump", on, reason, force)

def set_main_pump(on: bool, reason: str, force: bool = False) -> Dict[str, Any]:
    return set_relay("main_pump", on, reason, force)

def set_dosing_grow(on: bool, reason: str, force: bool = False) -> Dict[str, Any]:
    return set_relay("dosing_grow", on, reason, force)

def set_dosing_micro(on: bool, reason: str, force: bool = False) -> Dict[str, Any]:
    return set_relay("dosing_micro", on, reason, force)

def set_dosing_bloom(on: bool, reason: str, force: bool = False) -> Dict[str, Any]:
    return set_relay("dosing_bloom", on, reason, force)

def set_dosing_ph_up(on: bool, reason: str, force: bool = False) -> Dict[str, Any]:
    return set_relay("dosing_ph_up", on, reason, force)

# Generic set function
def set(name: str, on: bool, reason: str, force: bool = False) -> Dict[str, Any]:
    return set_relay(name, on, reason, force)